var settings = {
	app: [
		{
			"appTitle": "Mobile Feed Reader",
			"theme": "b",
			"mainPageTitle": "Feeds",
			"mainPageContent": "<p>This is tha main page content of test app #1</p><p>Chris is so cool he made this all work <b><i>dynamically!</i></b></p>",
			"secondPageTitle": "About",
			"secondPageContent": "<p>This will be some about us info for the app when it is finished.</p><p>Basically, I made a webpage with feeds on it when iGoogle ceased to exist, and this was the next logical step!</p>",
			"thirdPageTitle": "Account",
			"thirdPageContent": "<p>This is where you will be able to edit account things, and add/delete feeds.</p>"
		}
	]
};